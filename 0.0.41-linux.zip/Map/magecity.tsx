<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="magecity" tilewidth="32" tileheight="32" tilecount="360" columns="8">
 <image source="magecity.png" width="256" height="1450"/>
</tileset>
